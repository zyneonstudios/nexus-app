export default function isTableElement(element: Element): boolean;
